import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import https from 'https';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '15mb' }));

// Server-side Gemini AI Client with required telemetry header
const geminiApiKey = process.env.GEMINI_API_KEY || '';
let aiClient: GoogleGenAI | null = null;

if (geminiApiKey) {
  aiClient = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Module 09: AI Scientific Research Assistant endpoint
app.post('/api/gemini/research-assistant', async (req: Request, res: Response) => {
  try {
    const { message, context } = req.body;

    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'Valid non-empty message is required.' });
    }

    if (!geminiApiKey || !aiClient) {
      return res.status(503).json({
        error: 'Gemini API key is not configured. Please add GEMINI_API_KEY in the Secrets panel.',
        fallback: true,
      });
    }

    const systemInstruction = `You are the SPHEREx ATLAS Scientific Research Assistant, an elite astrophysicist and infrared observational astronomer specializing in NASA's SPHEREx mission (Spectro-Photometer for the History of the Universe, Epoch of Reionization and Ices Explorer).

SPHEREx Mission parameters:
- Observes the entire sky in 102 near-infrared spectral bands (0.75 - 5.00 µm) with resolving power R = 35 to 130 across 6 Linear Variable Filter (LVF) detector arrays.
- Science pillars:
  1. Cosmic Inflation: Measuring non-Gaussianity (f_NL) using 3D spatial clustering of hundreds of millions of galaxies.
  2. Galaxy Evolution: Extragalactic Background Light (EBL) fluctuations to probe the epoch of reionization and early stellar populations.
  3. Interstellar Ices & Planetary Systems: Measuring column densities of biogenic ices (H2O at 3.05 µm, CO2 at 4.27 µm, CO at 4.67 µm, CH4 at 3.32 µm, XCN at 4.62 µm) across young stellar objects, protostars, and molecular clouds.

SCIENTIFIC SAFETY RULES (MANDATORY):
1. Always categorize your findings using clear epistemic indicators:
   - [DIRECT OBSERVATION]: For measured physical quantities, coordinates, known spectral features.
   - [DERIVED PARAMETER]: For calculated values (e.g., column density, redshift, temperature).
   - [THEORETICAL MODEL]: For astrophysics models or evolutionary interpretations.
   - [MISSING / UNKNOWN]: When archive data or observational coverage is incomplete or unverified.
2. Never hallucinate observations, fake FITS header values, or invent non-existent discoveries.
3. Be rigorous, quantitative, precise, and supportive of peer-reviewed astrophysics research standards.
4. Support both English and Arabic questions naturally based on the user's language.

Current active context provided by the platform:
${JSON.stringify(context || {}, null, 2)}
`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: message,
      config: {
        systemInstruction,
      },
    });

    const reply = response.text || 'No response generated.';
    return res.json({ reply, model: 'gemini-2.5-flash' });
  } catch (err: any) {
    console.error('Gemini research assistant error:', err);
    return res.status(500).json({
      error: err.message || 'Failed to generate scientific analysis.',
    });
  }
});

// Helper coordinate formatters
function degToHms(raDeg: number): string {
  const totalHours = ((raDeg % 360 + 360) % 360) / 15;
  const h = Math.floor(totalHours);
  const m = Math.floor((totalHours - h) * 60);
  const s = ((totalHours - h - m / 60) * 3600).toFixed(2);
  return `${String(h).padStart(2, '0')}h ${String(m).padStart(2, '0')}m ${s.padStart(5, '0')}s`;
}

function degToDms(decDeg: number): string {
  const sign = decDeg < 0 ? '-' : '+';
  const abs = Math.abs(decDeg);
  const d = Math.floor(abs);
  const m = Math.floor((abs - d) * 60);
  const s = ((abs - d - m / 60) * 3600).toFixed(1);
  return `${sign}${String(d).padStart(2, '0')}° ${String(m).padStart(2, '0')}' ${s.padStart(4, '0')}"`;
}

// Convert Modified Julian Date (MJD) to ISO 8601 UTC string, or null if missing/invalid
function mjdToIsoString(mjd: number | null | undefined): string | null {
  if (mjd === null || mjd === undefined || !Number.isFinite(mjd)) {
    return null;
  }
  // MJD 0 = Nov 17 1858; Unix epoch (Jan 1 1970) = MJD 40587
  const unixMs = (mjd - 40587) * 86400 * 1000;
  const d = new Date(unixMs);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

/**
 * Robust HTTPS request helper for NASA/IPAC IRSA TAP services
 * Uses Node's native https to bypass Node 20+ undici fetch TLS/ALPN handshake resets (ECONNRESET) on IPAC servers.
 */
interface IrsaTapResponse {
  statusCode: number;
  data?: any;
  error?: string;
  isTimeout?: boolean;
}

function queryIrsaTap(adql: string, timeoutMs: number = 5000): Promise<IrsaTapResponse> {
  return new Promise((resolve) => {
    const postData = 'REQUEST=doQuery&LANG=ADQL&FORMAT=json&QUERY=' + encodeURIComponent(adql);
    const req = https.request(
      {
        hostname: 'irsa.ipac.caltech.edu',
        port: 443,
        path: '/TAP/sync',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(postData),
          'User-Agent': 'SPHEREx-ATLAS/1.0 (NASA/IPAC Archive Client; Space Apps)',
          'Accept': 'application/json, text/plain, */*',
        },
        timeout: timeoutMs,
      },
      (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          body += chunk;
        });
        res.on('end', () => {
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            try {
              const parsed = JSON.parse(body);
              resolve({ statusCode: res.statusCode, data: parsed });
            } catch (err: any) {
              resolve({ statusCode: 502, error: `Invalid JSON from IRSA TAP: ${err.message}` });
            }
          } else {
            resolve({
              statusCode: res.statusCode || 502,
              error: `IRSA TAP HTTP ${res.statusCode}: ${body.slice(0, 300)}`,
            });
          }
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      resolve({ statusCode: 504, error: `IRSA TAP query timed out after ${timeoutMs}ms`, isTimeout: true });
    });

    req.on('error', (err) => {
      resolve({ statusCode: 502, error: `Connection to IRSA TAP failed: ${err.message}` });
    });

    req.write(postData);
    req.end();
  });
}

/**
 * HTTPS helper for CDS Sesame target name resolution
 */
function queryCdsSesame(targetName: string, timeoutMs: number = 3500): Promise<{ ok: boolean; text?: string; error?: string }> {
  return new Promise((resolve) => {
    const req = https.request(
      {
        hostname: 'cds.unistra.fr',
        port: 443,
        path: `/cgi-bin/nph-sesame/-oI/A?${encodeURIComponent(targetName)}`,
        method: 'GET',
        headers: {
          'User-Agent': 'SPHEREx-ATLAS/1.0 (Astronomical Target Resolver)',
          'Accept': 'text/plain, */*',
        },
        timeout: timeoutMs,
      },
      (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => {
          body += chunk;
        });
        res.on('end', () => {
          if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
            resolve({ ok: true, text: body });
          } else {
            resolve({ ok: false, error: `CDS Sesame returned HTTP ${res.statusCode}` });
          }
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, error: 'CDS Sesame lookup timed out.' });
    });

    req.on('error', (err) => {
      resolve({ ok: false, error: err.message });
    });

    req.end();
  });
}

// Built-in calibrated reference catalog for offline fallback & benchmark cross-matching
const LOCAL_TARGETS: Record<string, any> = {
  'orion': {
    target: 'Orion Nebula (M42)',
    ra: 83.8221,
    dec: -5.3911,
    raHms: '05h 35m 17.3s',
    decDms: '-05° 23\' 28.0"',
    objectType: 'HII Region / Star-Forming Complex',
    canonicalName: 'Messier 42 / Orion Nebula',
  },
  'm42': {
    target: 'Orion Nebula (M42)',
    ra: 83.8221,
    dec: -5.3911,
    raHms: '05h 35m 17.3s',
    decDms: '-05° 23\' 28.0"',
    objectType: 'HII Region / Star-Forming Complex',
    canonicalName: 'Messier 42',
  },
  'm31': {
    target: 'Andromeda Galaxy (M31)',
    ra: 10.6847,
    dec: 41.2687,
    raHms: '00h 42m 44.3s',
    decDms: '+41° 16\' 07.5"',
    objectType: 'Spiral Galaxy (SA(s)b)',
    canonicalName: 'Messier 31',
  },
  'andromeda': {
    target: 'Andromeda Galaxy (M31)',
    ra: 10.6847,
    dec: 41.2687,
    raHms: '00h 42m 44.3s',
    decDms: '+41° 16\' 07.5"',
    objectType: 'Spiral Galaxy (SA(s)b)',
    canonicalName: 'Messier 31',
  },
  'trappist-1': {
    target: 'TRAPPIST-1',
    ra: 346.622,
    dec: -5.0414,
    raHms: '23h 06m 29.3s',
    decDms: '-05° 02\' 29.0"',
    objectType: 'Ultracool M-Dwarf Planetary System',
    canonicalName: '2MASS J23062928-0502285',
  },
  'cosmos': {
    target: 'COSMOS Deep Field',
    ra: 150.1192,
    dec: 2.2058,
    raHms: '10h 00m 28.6s',
    decDms: '+02° 12\' 21.0"',
    objectType: 'Cosmological Deep Extragalactic Survey Field',
    canonicalName: 'COSMOS Field',
  },
  'nep': {
    target: 'North Ecliptic Pole (NEP)',
    ra: 270.0000,
    dec: 66.5607,
    raHms: '18h 00m 00.0s',
    decDms: '+66° 33\' 38.5"',
    objectType: 'SPHEREx Deep Calibration Field (>1000x coverage)',
    canonicalName: 'NEP Deep Survey Field',
  },
  'sep': {
    target: 'South Ecliptic Pole (SEP)',
    ra: 90.0000,
    dec: -66.5607,
    raHms: '06h 00m 00.0s',
    decDms: '-66° 33\' 38.5"',
    objectType: 'SPHEREx Deep Calibration Field (>1000x coverage)',
    canonicalName: 'SEP Deep Survey Field',
  },
  'm82': {
    target: 'Cigar Galaxy (M82)',
    ra: 148.9685,
    dec: 69.6797,
    raHms: '09h 55m 52.4s',
    decDms: '+69° 40\' 47.0"',
    objectType: 'Starburst Galaxy / Infrared Hyper-Emitter',
    canonicalName: 'Messier 82',
  },
  'betelgeuse': {
    target: 'Betelgeuse (Alpha Orionis)',
    ra: 88.7929,
    dec: 7.4071,
    raHms: '05h 55m 10.3s',
    decDms: '+07° 24\' 25.4"',
    objectType: 'Red Supergiant Star (M1-2 Ia-ab)',
    canonicalName: 'Alpha Orionis',
  },
  'hd 189733': {
    target: 'HD 189733',
    ra: 300.182,
    dec: 22.7108,
    raHms: '20h 00m 43.7s',
    decDms: '+22° 42\' 39.0"',
    objectType: 'Exoplanet Host Star with Atmospheric Water',
    canonicalName: 'HD 189733',
  },
  'barnard': {
    target: "Barnard's Star (High Proper Motion)",
    ra: 269.4521,
    dec: 4.6934,
    raHms: '17h 57m 48.50s',
    decDms: '+04° 41\' 36.2"',
    objectType: 'High Proper Motion M-Dwarf (10.3"/yr)',
    canonicalName: "Barnard's Star / BD+04 3561a",
  },
  'barnards star': {
    target: "Barnard's Star (High Proper Motion)",
    ra: 269.4521,
    dec: 4.6934,
    raHms: '17h 57m 48.50s',
    decDms: '+04° 41\' 36.2"',
    objectType: 'High Proper Motion M-Dwarf (10.3"/yr)',
    canonicalName: "Barnard's Star / BD+04 3561a",
  },
  'wise 0855': {
    target: 'WISE J0855-0714 (Coldest Sub-Brown Dwarf)',
    ra: 133.7951,
    dec: -7.2452,
    raHms: '08h 55m 10.831s',
    decDms: '-07° 14\' 42.53"',
    objectType: 'Y4 Sub-Brown Dwarf (T ~ 250 K)',
    canonicalName: 'WISE J085510.83-071442.5',
  },
  'wise0855': {
    target: 'WISE J0855-0714 (Coldest Sub-Brown Dwarf)',
    ra: 133.7951,
    dec: -7.2452,
    raHms: '08h 55m 10.831s',
    decDms: '-07° 14\' 42.53"',
    objectType: 'Y4 Sub-Brown Dwarf (T ~ 250 K)',
    canonicalName: 'WISE J085510.83-071442.5',
  },
  'r draconis': {
    target: 'R Draconis (Extreme Mira Variable)',
    ra: 248.1675,
    dec: 66.7550,
    raHms: '16h 32m 40.20s',
    decDms: '+66° 45\' 18.0"',
    objectType: 'M3e-M9e Mira Variable Star',
    canonicalName: 'R Dra / HD 149214',
  },
  'r dra': {
    target: 'R Draconis (Extreme Mira Variable)',
    ra: 248.1675,
    dec: 66.7550,
    raHms: '16h 32m 40.20s',
    decDms: '+66° 45\' 18.0"',
    objectType: 'M3e-M9e Mira Variable Star',
    canonicalName: 'R Dra / HD 149214',
  },
  'rw aurigae': {
    target: 'RW Aurigae (Accretion & Dust Occultation)',
    ra: 76.9563,
    dec: 30.4014,
    raHms: '05h 07m 49.50s',
    decDms: '+30° 24\' 05.0"',
    objectType: 'Classical T Tauri Binary Variable',
    canonicalName: 'RW Aur / HIP 23873',
  },
  'rw aur': {
    target: 'RW Aurigae (Accretion & Dust Occultation)',
    ra: 76.9563,
    dec: 30.4014,
    raHms: '05h 07m 49.50s',
    decDms: '+30° 24\' 05.0"',
    objectType: 'Classical T Tauri Binary Variable',
    canonicalName: 'RW Aur / HIP 23873',
  },
  'epsilon indi b': {
    target: 'Epsilon Indi B (Cold Binary Brown Dwarf)',
    ra: 331.0438,
    dec: -56.7828,
    raHms: '22h 04m 10.50s',
    decDms: '-56° 46\' 58.0"',
    objectType: 'T1+T6 Binary Brown Dwarf (pm: 4.7"/yr)',
    canonicalName: 'eps Ind B / GJ 845 B',
  },
  'eps ind b': {
    target: 'Epsilon Indi B (Cold Binary Brown Dwarf)',
    ra: 331.0438,
    dec: -56.7828,
    raHms: '22h 04m 10.50s',
    decDms: '-56° 46\' 58.0"',
    objectType: 'T1+T6 Binary Brown Dwarf (pm: 4.7"/yr)',
    canonicalName: 'eps Ind B / GJ 845 B',
  },
};

function searchLocalCatalog(query: string) {
  const q = query.toLowerCase().trim();
  for (const [key, val] of Object.entries(LOCAL_TARGETS)) {
    if (key === q || val.target.toLowerCase().includes(q) || val.canonicalName.toLowerCase().includes(q)) {
      return val;
    }
  }
  return null;
}

// Module 04: Astronomical Target Resolver (CDS Sesame / SIMBAD / NED proxy with calibrated fallback)
app.get('/api/astronomy/resolve', async (req: Request, res: Response) => {
  const targetParam = req.query.target;

  // 1. Rigorous input validation
  if (!targetParam || typeof targetParam !== 'string' || !targetParam.trim()) {
    return res.status(400).json({
      error: 'Target query parameter is required and must be non-empty text.',
      dataStatus: 'UNAVAILABLE DATA',
    });
  }

  const targetName = targetParam.trim();
  if (targetName.length > 128) {
    return res.status(400).json({
      error: 'Target name exceeds maximum allowed length of 128 characters.',
      dataStatus: 'UNAVAILABLE DATA',
    });
  }

  try {
    // 2. Attempt upstream CDS Sesame lookup via reliable HTTPS request
    const sesameRes = await queryCdsSesame(targetName, 3500);

    if (sesameRes.ok && sesameRes.text) {
      const text = sesameRes.text;
      // Parse Sesame standard response (%J ra dec)
      const jMatch = text.match(/%J\s+([0-9.\-+]+)\s+([0-9.\-+]+)/);
      const typeMatch = text.match(/%T\s+([^\n\r]+)/);
      const onameMatch = text.match(/%C\.0\s+([^\n\r]+)/);

      if (jMatch) {
        const ra = parseFloat(jMatch[1]);
        const dec = parseFloat(jMatch[2]);
        return res.json({
          target: targetName,
          found: true,
          source: 'CDS Sesame / SIMBAD (Strasbourg Astronomical Data Center)',
          dataStatus: 'EXTERNAL CATALOG DATA',
          ra,
          dec,
          raHms: degToHms(ra),
          decDms: degToDms(dec),
          objectType: typeMatch ? typeMatch[1].trim() : 'Astronomical Source',
          canonicalName: onameMatch ? onameMatch[1].trim() : targetName,
          provenance: 'Authoritative CDS Sesame Name Resolver (Live)',
        });
      }
    }

    // 3. Fallback to calibrated astronomical catalog if CDS is unreachable or object not found
    const localMatch = searchLocalCatalog(targetName);
    if (localMatch) {
      return res.json({
        ...localMatch,
        found: true,
        source: 'Calibrated Astronomical Reference Catalog',
        dataStatus: 'EXTERNAL CATALOG DATA',
        provenance: 'Calibrated Astronomical Reference Database',
      });
    }

    // 4. Honest not-found response (never fabricate coordinates)
    return res.status(404).json({
      target: targetName,
      found: false,
      dataStatus: 'UNAVAILABLE DATA',
      error: `Target "${targetName}" could not be resolved by CDS Sesame or the reference catalog. Please provide coordinates directly (RA/Dec).`,
    });
  } catch (err: any) {
    return res.status(500).json({
      error: 'Astronomical resolver encountered an unexpected internal server error.',
      dataStatus: 'UNAVAILABLE DATA',
      details: err.message,
    });
  }
});

// NASA / IPAC IRSA TAP Archive Status Endpoint
app.get('/api/archive/status', async (_req: Request, res: Response) => {
  const startTime = Date.now();
  try {
    const tapRes = await queryIrsaTap("SELECT table_name, description FROM TAP_SCHEMA.tables WHERE schema_name='spherex'", 4500);
    const latencyMs = Date.now() - startTime;

    if (tapRes.statusCode === 200 && tapRes.data) {
      const rows = tapRes.data?.VOTABLE?.RESOURCE_ARRAY?.[0]?.TABLE?.DATA?.TABLEDATA || [];
      const tables = rows.map((r: any[]) => ({ name: r[0], description: r[1] }));

      return res.json({
        connected: true,
        archive: 'NASA/IPAC Infrared Science Archive (IRSA)',
        endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
        protocol: 'IVOA Table Access Protocol (TAP) 1.0 / ObsCore',
        latencyMs,
        verifiedTables: tables,
        dataReleaseStatus: 'SPHEREx Quick Release (QR2/QR3) rolling weekly products',
      });
    }

    return res.status(tapRes.statusCode || 502).json({
      connected: false,
      archive: 'NASA/IPAC Infrared Science Archive (IRSA)',
      endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
      error: tapRes.error || `Upstream TAP service responded with HTTP ${tapRes.statusCode}`,
      isTimeout: tapRes.isTimeout || false,
      latencyMs,
    });
  } catch (err: any) {
    return res.status(503).json({
      connected: false,
      archive: 'NASA/IPAC Infrared Science Archive (IRSA)',
      endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
      error: err.message,
    });
  }
});

// NASA / IPAC IRSA TAP Archive Query Endpoint
app.post('/api/archive/search', async (req: Request, res: Response) => {
  const startTime = Date.now();
  try {
    const { ra, dec, fov = 0.5 } = req.body;

    // 1. Strict input validation
    if (ra === undefined || ra === null || isNaN(Number(ra))) {
      return res.status(400).json({
        error: 'Right Ascension (RA) is required and must be a valid number in degrees [0, 360).',
        dataStatus: 'UNAVAILABLE DATA',
      });
    }

    if (dec === undefined || dec === null || isNaN(Number(dec))) {
      return res.status(400).json({
        error: 'Declination (Dec) is required and must be a valid number in degrees [-90, +90].',
        dataStatus: 'UNAVAILABLE DATA',
      });
    }

    const numRa = parseFloat(ra);
    const numDec = parseFloat(dec);

    if (numRa < 0 || numRa >= 360) {
      return res.status(400).json({
        error: `Right Ascension ${numRa}° is out of valid celestial range [0, 360).`,
        dataStatus: 'UNAVAILABLE DATA',
      });
    }

    if (numDec < -90 || numDec > 90) {
      return res.status(400).json({
        error: `Declination ${numDec}° is out of valid celestial range [-90, +90].`,
        dataStatus: 'UNAVAILABLE DATA',
      });
    }

    const numFov = parseFloat(fov);
    if (isNaN(numFov) || numFov <= 0 || numFov > 15.0) {
      return res.status(400).json({
        error: 'Field of view (fov) must be a positive number in degrees (0 < fov <= 15.0).',
        dataStatus: 'UNAVAILABLE DATA',
      });
    }

    // FOV is passed as diameter in degrees; convert to cone search radius
    const radiusDeg = numFov / 2;
    const rawLimit = Number(req.body?.limit ?? 100);
    const limit = Number.isFinite(rawLimit) ? Math.min(Math.max(1, Math.floor(rawLimit)), 500) : 100;

    // 2. Official ADQL query against documented IRSA ObsCore schema (spherex.obscore)
    const adql = `SELECT TOP ${limit} obs_id, target_name, s_ra, s_dec, energy_bandpassname, em_min, em_max, t_min, t_max, t_exptime, access_url, access_format, dataproduct_type, calib_level, obs_title, obs_collection, facility_name, instrument_name FROM spherex.obscore WHERE 1 = CONTAINS(POINT('ICRS', s_ra, s_dec), CIRCLE('ICRS', ${numRa.toFixed(5)}, ${numDec.toFixed(5)}, ${radiusDeg.toFixed(4)})) ORDER BY t_min ASC`;

    // 3. Query official NASA/IPAC TAP service with 25000ms timeout
    const tapTimeoutMs = 25000;
    const tapRes = await queryIrsaTap(adql, tapTimeoutMs);
    const queryTimeMs = Date.now() - startTime;

    // Handle timeout
    if (tapRes.isTimeout) {
      return res.status(504).json({
        spherexAvailable: false,
        dataStatus: 'UNAVAILABLE DATA',
        count: 0,
        observations: [],
        error: `Archive query to NASA/IPAC IRSA TAP timed out after ${tapTimeoutMs}ms.`,
        archiveTimeout: true,
        ra: numRa,
        dec: numDec,
        radiusDeg,
        notice: 'The upstream NASA/IPAC IRSA TAP server did not respond within the allocated timeout window. IRSA synchronous TAP queues may be experiencing high latency.',
        archiveService: {
          endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
          table: 'spherex.obscore',
          timeoutMs: tapTimeoutMs,
        },
      });
    }

    // Handle upstream errors
    if (tapRes.statusCode !== 200 || !tapRes.data) {
      return res.status(tapRes.statusCode || 502).json({
        spherexAvailable: false,
        dataStatus: 'UNAVAILABLE DATA',
        count: 0,
        observations: [],
        error: `NASA/IPAC IRSA TAP query failed: ${tapRes.error}`,
        queryTimeMs,
        archiveService: {
          endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
          table: 'spherex.obscore',
        },
      });
    }

    const rows = tapRes.data?.VOTABLE?.RESOURCE_ARRAY?.[0]?.TABLE?.DATA?.TABLEDATA || [];

    // 4. Handle genuine observation products if present
    if (rows.length > 0) {
      const realObservations = rows.map((r: any[]) => {
        const obsId = String(r[0]);
        const targetRegion = r[1] ? String(r[1]) : (r[14] ? String(r[14]) : 'SPHEREx Observation');
        const sRa = Number(r[2]);
        const sDec = Number(r[3]);
        const band = r[4] ? String(r[4]) : 'SPHEREx LVF';
        const emMin = r[5] ? Number(r[5]) : null;
        const emMax = r[6] ? Number(r[6]) : null;
        const tMinMjd = r[7] ? Number(r[7]) : null;
        const tMaxMjd = r[8] ? Number(r[8]) : null;
        const exposureSec = r[9] ? Number(r[9]) : 0;
        const accessUrl = r[10] ? String(r[10]) : undefined;
        const accessFormat = r[11] ? String(r[11]) : 'application/fits';
        const calibLevel = r[13];

        let dataProductLevel = 'Level 2 (Calibrated Images)';
        if (calibLevel === 3) dataProductLevel = 'Level 3 (Spectral Cubes)';
        if (calibLevel === 1) dataProductLevel = 'Level 1A (Raw)';

        return {
          id: obsId,
          surveyPass: 'Quick Release',
          targetRegion,
          ra: sRa,
          dec: sDec,
          dateStart: mjdToIsoString(tMinMjd),
          dateEnd: mjdToIsoString(tMaxMjd),
          exposureSec,
          instrument: r[17] ? String(r[17]) : 'SPHEREx LVF',
          band,
          wavelengthRangeUm:
            emMin !== null && emMax !== null && Number.isFinite(emMin) && Number.isFinite(emMax)
              ? [Number((emMin * 1e6).toFixed(3)), Number((emMax * 1e6).toFixed(3))]
              : undefined,
          dataProductLevel,
          irsaArchiveId: obsId,
          accessUrl,
          accessFormat,
          status: 'Completed',
          dataStatus: 'REAL ARCHIVE DATA',
          isSimulatedOrDemo: false,
          coverageOverlapCount: 1,
        };
      });

      return res.json({
        spherexAvailable: true,
        dataStatus: 'REAL ARCHIVE DATA',
        count: realObservations.length,
        observations: realObservations,
        source: 'NASA/IPAC IRSA SPHEREx TAP Archive (Live)',
        ra: numRa,
        dec: numDec,
        radiusDeg,
        notice: `Retrieved ${realObservations.length} genuine SPHEREx observation products from NASA/IPAC Infrared Science Archive.`,
        archiveService: {
          endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
          table: 'spherex.obscore',
          queryStatus: 'OK',
          queryTimeMs,
        },
      });
    }

    // 5. Honest empty/unavailable result when coordinates have no public data
    return res.json({
      spherexAvailable: false,
      dataStatus: 'UNAVAILABLE DATA',
      count: 0,
      observations: [],
      source: 'NASA/IPAC IRSA SPHEREx Archive',
      ra: numRa,
      dec: numDec,
      radiusDeg,
      notice: `No public SPHEREx observations are available for coordinates RA: ${numRa.toFixed(4)}°, Dec: ${numDec.toFixed(4)}° (FOV: ${radiusDeg}°). Public SPHEREx Quick Releases (QR2/QR3) currently cover designated calibration zones (such as the North Ecliptic Pole) and rolling survey swathes. This sky region has not yet been observed or publicly archived.`,
      archiveService: {
        endpoint: 'https://irsa.ipac.caltech.edu/TAP/sync',
        table: 'spherex.obscore',
        queryStatus: 'EMPTY_RESULT',
        queryTimeMs,
      },
    });
  } catch (err: any) {
    return res.status(500).json({
      error: 'Archive query failed due to an unexpected internal error.',
      dataStatus: 'UNAVAILABLE DATA',
      details: err.message,
    });
  }
});

// Safe Backend Proxy for Real FITS Product Retrieval from NASA/IPAC IRSA
const MAX_FITS_BYTES = 100 * 1024 * 1024; // 100 MB limit

function fetchFitsWithRedirects(targetUrl: string, redirectsLeft = 5, timeoutMs = 15000): Promise<{ statusCode: number; contentType: string; buffer?: Buffer; error?: string; isTimeout?: boolean }> {
  return new Promise((resolve) => {
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(targetUrl);
    } catch {
      return resolve({ statusCode: 400, contentType: '', error: 'Invalid product URL.' });
    }

    if (parsedUrl.protocol !== 'https:') {
      return resolve({ statusCode: 400, contentType: '', error: 'Only HTTPS product URLs are permitted.' });
    }

    const host = parsedUrl.hostname.toLowerCase();
    const isAllowedHost =
      host === 'irsa.ipac.caltech.edu' ||
      host.endsWith('.ipac.caltech.edu') ||
      /^nasa-irsa-spherex(\.s3(\.[a-z0-9-]+)?)?\.amazonaws\.com$/.test(host) ||
      /^irsa-spherex[a-z0-9-]*\.s3(\.[a-z0-9-]+)?\.amazonaws\.com$/.test(host);

    if (!isAllowedHost) {
      return resolve({
        statusCode: 403,
        contentType: '',
        error: `Host "${host}" is not an authorized NASA/IPAC IRSA or AWS Open Data mirror.`,
      });
    }

    const req = https.request(
      {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || 443,
        path: parsedUrl.pathname + parsedUrl.search,
        method: 'GET',
        headers: {
          'User-Agent': 'SPHEREx-ATLAS/1.0 (NASA/IPAC FITS Client)',
          'Accept': 'application/fits, application/octet-stream, */*',
        },
        timeout: timeoutMs,
      },
      (res) => {
        const status = res.statusCode || 502;

        // Handle redirects
        if ([301, 302, 303, 307, 308].includes(status) && res.headers.location) {
          res.resume();
          if (redirectsLeft <= 0) {
            return resolve({ statusCode: 502, contentType: '', error: 'Too many redirects while retrieving FITS product.' });
          }
          const nextUrl = new URL(res.headers.location, targetUrl).toString();
          return fetchFitsWithRedirects(nextUrl, redirectsLeft - 1, timeoutMs).then(resolve);
        }

        const contentType = String(res.headers['content-type'] || '');
        const contentLength = Number(res.headers['content-length'] || 0);
        if (contentLength > MAX_FITS_BYTES) {
          res.destroy();
          return resolve({
            statusCode: 413,
            contentType,
            error: `FITS product size (${(contentLength / (1024 * 1024)).toFixed(1)} MB) exceeds 100 MB limit.`,
          });
        }

        if (status < 200 || status >= 300) {
          res.resume();
          return resolve({
            statusCode: status,
            contentType,
            error: `Upstream archive returned HTTP ${status} for FITS product.`,
          });
        }

        const chunks: Buffer[] = [];
        let totalBytes = 0;

        res.on('data', (chunk: Buffer) => {
          totalBytes += chunk.length;
          if (totalBytes > MAX_FITS_BYTES) {
            res.destroy();
            resolve({
              statusCode: 413,
              contentType,
              error: 'FITS product stream exceeded 100 MB download limit.',
            });
            return;
          }
          chunks.push(chunk);
        });

        res.on('end', () => {
          const buffer = Buffer.concat(chunks);
          resolve({ statusCode: status, contentType, buffer });
        });

        res.on('error', (err) => {
          resolve({ statusCode: 502, contentType, error: `Stream error: ${err.message}` });
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      resolve({ statusCode: 504, contentType: '', error: `FITS download timed out after ${timeoutMs}ms.`, isTimeout: true });
    });

    req.on('error', (err) => {
      resolve({ statusCode: 502, contentType: '', error: `Failed to connect to FITS product host: ${err.message}` });
    });

    req.end();
  });
}

function decodeXmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

function extractFitsUrlFromDataLink(xmlText: string): string | null {
  const tdMatches = xmlText.match(/<(?:[a-zA-Z0-9_-]+:)?TD[^>]*>([\s\S]*?)<\/(?:[a-zA-Z0-9_-]+:)?TD>/gi);
  if (!tdMatches) return null;
  const urls = tdMatches
    .map((m) => decodeXmlEntities(m.replace(/<\/?(?:[a-zA-Z0-9_-]+:)?TD[^>]*>/gi, '').trim()))
    .filter((u) => u.startsWith('https://'));

  // Prefer direct .fits or .fits.gz URLs
  const directFits = urls.find((u) => /\.fits(\.gz)?(\?|$)/i.test(u));
  if (directFits) return directFits;

  // Fallback to any non-datalink IRSA/AWS URL
  const nonDataLink = urls.find((u) => !u.includes('/datalink/'));
  return nonDataLink || null;
}

app.get('/api/archive/fits', async (req: Request, res: Response) => {
  const productUrl = req.query.url;
  if (!productUrl || typeof productUrl !== 'string' || !productUrl.trim()) {
    return res.status(400).json({
      error: 'Query parameter "url" is required.',
      dataStatus: 'UNAVAILABLE DATA',
    });
  }

  let result = await fetchFitsWithRedirects(productUrl.trim(), 5, 15000);

  if (result.error || !result.buffer) {
    return res.status(result.statusCode || 502).json({
      error: result.error || 'Failed to retrieve FITS product.',
      dataStatus: 'UNAVAILABLE DATA',
      isTimeout: result.isTimeout || false,
    });
  }

  // If the response is an IVOA DataLink VOTable XML, resolve the underlying FITS URL
  const prefixText = result.buffer.subarray(0, 512).toString('utf8');
  if (prefixText.includes('<VOTABLE') || result.contentType.includes('votable') || result.contentType.includes('xml')) {
    const fullXml = result.buffer.toString('utf8');
    const resolvedFitsUrl = extractFitsUrlFromDataLink(fullXml);
    if (!resolvedFitsUrl) {
      return res.status(422).json({
        error: 'DataLink descriptor did not contain a downloadable HTTPS FITS product URL.',
        dataStatus: 'UNAVAILABLE DATA',
      });
    }
    result = await fetchFitsWithRedirects(resolvedFitsUrl, 5, 25000);
    if (result.error || !result.buffer) {
      return res.status(result.statusCode || 502).json({
        error: result.error || 'Failed to retrieve resolved FITS product.',
        dataStatus: 'UNAVAILABLE DATA',
        isTimeout: result.isTimeout || false,
      });
    }
  }

  // Validate FITS magic header ("SIMPLE  =")
  if (result.buffer.length < 2880) {
    return res.status(422).json({
      error: `Retrieved resource (${result.buffer.length} bytes, Content-Type: ${result.contentType || 'unknown'}) is smaller than a valid 2880-byte FITS block.`,
      dataStatus: 'UNAVAILABLE DATA',
    });
  }

  const headerPrefix = result.buffer.subarray(0, 80).toString('ascii');
  if (!headerPrefix.startsWith('SIMPLE  =')) {
    return res.status(422).json({
      error: `Retrieved resource (Content-Type: ${result.contentType || 'unknown'}) does not begin with a valid FITS "SIMPLE  =" header.`,
      dataStatus: 'UNAVAILABLE DATA',
    });
  }

  res.setHeader('Content-Type', 'application/fits');
  res.setHeader('X-Data-Provenance', 'REAL ARCHIVE DATA');
  return res.send(result.buffer);
});

// Dedicated Benchmark Simulation Endpoint (Completely isolated from real archive search)
app.get('/api/archive/benchmark-simulation', (req: Request, res: Response) => {
  const targetKey = String(req.query.target || 'barnard').toLowerCase();

  const BENCHMARKS: Record<string, any> = {
    'barnard': {
      target: "Barnard's Star Benchmark",
      ra: 269.4521,
      dec: 4.6934,
      motionType: 'Proper Motion (10.3"/yr)',
      epochs: [
        {
          id: 'SIM-BARNARD-EP1',
          epochLabel: 'Benchmark Epoch 2020.5',
          date: '2020-06-15',
          displacementArcsec: 0.0,
          fitsKey: 'barnard_star_epoch1',
        },
        {
          id: 'SIM-BARNARD-EP2',
          epochLabel: 'Benchmark Epoch 2024.5',
          date: '2024-06-15',
          displacementArcsec: 41.4,
          fitsKey: 'barnard_star_epoch2',
        },
      ],
    },
    'wise0855': {
      target: 'WISE J0855-0714 Benchmark',
      ra: 133.7951,
      dec: -7.2452,
      motionType: 'Sub-Brown Dwarf Proper Motion (8.2"/yr)',
      epochs: [
        {
          id: 'SIM-WISE0855-EP1',
          epochLabel: 'Benchmark Epoch 2021.2',
          date: '2021-03-20',
          displacementArcsec: 0.0,
          fitsKey: 'wise0855_epoch1',
        },
        {
          id: 'SIM-WISE0855-EP2',
          epochLabel: 'Benchmark Epoch 2024.2',
          date: '2024-03-20',
          displacementArcsec: 24.6,
          fitsKey: 'wise0855_epoch2',
        },
      ],
    },
    'r_draconis': {
      target: 'R Draconis Benchmark',
      ra: 248.1675,
      dec: 66.755,
      motionType: 'Mira Pulsation Variability (>8x flux change)',
      epochs: [
        {
          id: 'SIM-RDRA-MAX',
          epochLabel: 'Benchmark Maximum Phase',
          date: '2025-05-10',
          fluxMjySr: 820,
          fitsKey: 'r_draconis_max',
        },
        {
          id: 'SIM-RDRA-MIN',
          epochLabel: 'Benchmark Minimum Phase',
          date: '2025-09-12',
          fluxMjySr: 85,
          fitsKey: 'r_draconis_min',
        },
      ],
    },
    'rw_aurigae': {
      target: 'RW Aurigae Benchmark',
      ra: 76.9563,
      dec: 30.4014,
      motionType: 'Circumstellar Dust Streamer Occultation',
      epochs: [
        {
          id: 'SIM-RWAUR-BRIGHT',
          epochLabel: 'Benchmark Normal Bright Phase',
          date: '2024-11-01',
          fluxMjySr: 460,
          fitsKey: 'rw_aurigae_bright',
        },
        {
          id: 'SIM-RWAUR-DIM',
          epochLabel: 'Benchmark Dust Occultation Phase',
          date: '2025-01-20',
          fluxMjySr: 120,
          fitsKey: 'rw_aurigae_dim',
        },
      ],
    },
    'epsilon_indi': {
      target: 'Epsilon Indi B Benchmark',
      ra: 331.0438,
      dec: -56.7828,
      motionType: 'Binary Brown Dwarf Proper Motion (4.7"/yr)',
      epochs: [
        {
          id: 'SIM-EPSIND-EP1',
          epochLabel: 'Benchmark Epoch 2020.8',
          date: '2020-10-15',
          displacementArcsec: 0.0,
          fitsKey: 'epsilon_indi_epoch1',
        },
        {
          id: 'SIM-EPSIND-EP2',
          epochLabel: 'Benchmark Epoch 2024.8',
          date: '2024-10-15',
          displacementArcsec: 18.8,
          fitsKey: 'epsilon_indi_epoch2',
        },
      ],
    },
  };

  const benchmark = BENCHMARKS[targetKey] || BENCHMARKS['barnard'];

  return res.json({
    ...benchmark,
    dataStatus: 'SIMULATED DEMO DATA',
    isSimulatedOrDemo: true,
    provenance: 'Astrophysical Multi-Epoch Simulation Engine',
    disclaimer: 'SIMULATED DEMO DATA — NOT REAL SPHEREx OBSERVATIONS. Provided for time-domain and proper-motion algorithmic evaluation.',
  });
});

// Development Vite Middleware setup or static production serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`SPHEREx ATLAS server running at http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start SPHEREx ATLAS server:', err);
  process.exit(1);
});
